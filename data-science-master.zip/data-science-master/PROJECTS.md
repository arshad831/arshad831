<h3 align="center">Open Source Society University</h3>
<p align="center">
	<i>Knowledge and skills as commons</i>
</p>

<h4 align="center">Projects ideas</h4>

>Here, we are providing a list curated by the community of exercices and projects to practice and reinforce the skills we try to master.

Projects created by OSSU's students for each course of our [**Data Science**](https://github.com/open-source-society/data-science) curriculum.

### Linear Algebra
Project Title | Description | Authors | Repository
:-- | :-- | :--: | :--
| | |
 
### Single Variable Calculus
Project Title | Description | Authors | Repository
:-- | :-- | :--: | :--
| slope-field | Slope-field generation written in Haskell | Mahdi Dibaiee | https://github.com/mdibaiee/slope-field

### Multivariable Calculus
Project Title | Description | Authors | Repository
:-- | :-- | :--: | :--
| | |

### Python
Project Title | Description | Authors | Repository
:-- | :-- | :--: | :--
| | |

### Probability and Statistics
Project Title | Description | Authors | Repository
:-- | :-- | :--: | :--
| | |

### Introduction to Data Science
Project Title | Description | Authors | Repository
:-- | :-- | :--: | :--
| | |

### Machine Learning
Project Title | Description | Authors | Repository
:-- | :-- | :--: | :--
| | |

### Convex Optimization
Project Title | Description | Authors | Repository
:-- | :-- | :--: | :--
| | |


### Big Data
Project Title | Description | Authors | Repository
:-- | :-- | :--: | :--
| | |

### Database
Project Title | Description | Authors | Repository
:-- | :-- | :--: | :--
| | |

### Natural Language Processing
Project Title | Description | Authors | Repository
:-- | :-- | :--: | :--
| | |

### Deep Learning
Project Title | Description | Authors | Repository
:-- | :-- | :--: | :--
| | |
