# Data Science - Extra Resources

## Books

- [Python](#python)
- [Data Analysis](#data-analysis)
- [Data Visualization](#data-visualization)
- [Web Scraping](#web-scraping)
- [Databases and SQL](#databases-and-sql)
- [Statistics](#statistics)
- [Linear Algebra](#linear-algebra)
- [Machine Learning](#machine-learning)
- [Data Science](#data-science)
- [Big Data](#big-data)


---



### Python

Name | Author | ISBN 
:-- | :--: | :--:


### Data Analysis

Name | Author | ISBN 
:-- | :--: | :--:


### Data Visualization

Name | Author | ISBN 
:-- | :--: | :--:


### Web Scraping

Name | Author | ISBN 
:-- | :--: | :--:


### Databases and SQL

Name | Author | ISBN 
:-- | :--: | :--:

### Statistics


Name | Author | ISBN 
:-- | :--: | :--:


### Linear Algebra

Name | Author | ISBN 
:-- | :--: | :--:
